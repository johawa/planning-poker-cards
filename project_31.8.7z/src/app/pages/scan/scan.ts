import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { NfcService } from '../../services/nfc-reader.service';
import { saveToFile } from '../../helpers/helpers';
import {
  IonItem,
  IonLabel,
  IonInput,
  IonButton,
  IonText,
  IonList,
  IonListHeader,
  IonContent,
  IonChip,
  IonIcon,
} from '@ionic/angular/standalone';
import { SelectedOptions, SelectService } from '../../services/select.service';
import { Observable, timer, expand, map } from 'rxjs';

function getRandomDelay(): number {
  return Math.floor(Math.random() * (5000 - 1500 + 1)) + 1500; // 1500 to 5000 ms
}

function getRandomNumber(): number {
  return Math.floor(Math.random() * 10) + 1; // 1 to 10
}

const randomObservable = new Observable<number>((observer) => {
  const initialDelay = getRandomDelay();

  timer(initialDelay).subscribe(() => {
    observer.next(getRandomNumber());
  });
}).pipe(expand(() => timer(getRandomDelay()).pipe(map(() => getRandomNumber()))));

@Component({
  selector: 'app-scan',
  standalone: true,
  imports: [
    IonItem,
    IonLabel,

    IonButton,
    FormsModule,
    IonText,
    IonList,
    IonLabel,
    IonListHeader,
    IonContent,
    IonChip,
    IonIcon,
  ],
  templateUrl: 'scan.html',
  styleUrls: ['./scan.css'],
})
export class ScanComponent {
  userInput = '';
  state!: SelectedOptions;

  msg = signal('Hello');

  // private audio = new Audio('assets/sound.wav');

  constructor(
    private storageService: StorageService,
    private nfc: NfcService,
    private selectService: SelectService
  ) {
    this.state = this.selectService.getState();

    // randomObservable.subscribe((value) => {
    //   console.log('Random Value:', value, this.audio);
    //   this.audio.currentTime = 0;
    //   this.audio.play().catch((err) => console.error('Audio playback failed:', err));
    // });
  }

  async scanNfc() {
    this.msg.set('scanning');

    try {
      // @ts-ignore
      const ndef = new NDEFReader(); // TypeScript will not check this line
      await ndef.scan();
      this.msg.set('> Scan started');

      ndef.addEventListener('readingerror', () => {
        this.msg.set('Argh! Cannot read data from the NFC tag. Try another one?');
      });

      ndef.addEventListener('reading', ({ message, serialNumber }: any) => {
        for (const record of message.records) {
          switch (record.recordType) {
            case 'text':
              const textDecoder = new TextDecoder(record.encoding);
              this.msg.set(`Message: ${textDecoder.decode(record.data)}`);
              break;
            default:
              this.msg.set(`Message: record type not detected`);
          }
        }
      });
    } catch (error) {
      this.msg.set('Argh! ' + error);
    }
  }

  saveInput() {
    const sessionId = this.selectService.getSessionID();
    const pickerId = 11; // will come from nfc chip;
    const amount = 3;
    const update = {
      pickerId,
      amount,
      sessionId,
    };

    // this.storageService.save(update);
    this.storageService.mockDB();
    this.userInput = '';
  }
}
