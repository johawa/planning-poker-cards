import { Component } from '@angular/core';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
} from '@ionic/angular/standalone';
import { ScanComponent } from '../scan/scan';

@Component({
  selector: 'app-step-three',
  templateUrl: 'step-three.component.html',
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, IonBackButton, IonButtons, ScanComponent],
})
export class StepThreeComponent {
  component = ScanComponent;

  constructor() {}
}
