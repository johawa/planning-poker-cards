import { Component } from '@angular/core';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonNav,
} from '@ionic/angular/standalone';
import { ScanComponent } from '../scan/scan';
import { StepThreeComponent } from './step-three.component';
import { SelectService } from '../../services/select.service';

@Component({
  selector: 'app-step-two',
  templateUrl: 'step-two.component.html',
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonBackButton,
    IonButtons,
    IonCard,
    IonCardHeader,
    IonCardTitle,
  ],
})
export class StepTwoComponent {
  component = ScanComponent;

  constructor(private nav: IonNav, private selectService: SelectService) {}

  handleSelect(subSelectionFromEvent: number) {
    this.selectService.updateWeight(subSelectionFromEvent);
    this.selectService.startSession();

    this.nav.push(StepThreeComponent);
  }
}
