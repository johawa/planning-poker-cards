import { Component } from '@angular/core';
import {
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonNav,
  IonTitle,
  IonToolbar,
} from '@ionic/angular/standalone';
import { ScanComponent } from '../scan/scan';
import { StepTwoComponent } from './step-two.component';
import { BerryType, SelectService } from '../../services/select.service';

@Component({
  selector: 'app-page-one',
  templateUrl: 'step-one.component.html',
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, IonCard, IonCardHeader, IonCardTitle],
})
export class StepOneComponent {
  component = ScanComponent;

  constructor(private nav: IonNav, private selectService: SelectService) {}

  handleSelect(selectionFromEvent: BerryType) {
    this.selectService.updateType(selectionFromEvent);
    this.nav.push(StepTwoComponent);
  }
}
