import { Component } from '@angular/core';
import {
  IonHeader,
  IonTitle,
  IonToolbar,
  IonContent,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonNav,
  IonButton,
  IonText,
  IonButtons,
} from '@ionic/angular/standalone';
import { StorageService } from '../../services/storage.service';
import { AsyncPipe } from '@angular/common';
import { map, Observable } from 'rxjs';
import { TableComponent } from './table';

@Component({
  selector: 'app-storage',
  imports: [
    IonHeader,
    IonTitle,
    IonToolbar,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    AsyncPipe,
    IonListHeader,
    IonButton,
    IonButtons,
    IonText,
  ],
  templateUrl: 'tables-overview.html',
  standalone: true,
})
export class TablesOverviewComponent {
  tableData$!: Observable<string[]>;

  constructor(readonly storageService: StorageService, private nav: IonNav) {}

  ionViewWillEnter() {
    console.log('will enter');
    this.refresh();
  }

  selectTable(tableName: any) {
    this.nav.push(TableComponent, { sessionId: tableName });
  }

  refresh() {
    this.tableData$ = this.storageService.getAll().pipe(
      map((data) => {
        console.log('alldata', data);
        return Array.from(new Set(data.map((r) => r.sessionId)));
      })
    );
  }
}
