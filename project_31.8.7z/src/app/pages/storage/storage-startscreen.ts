import { Component } from '@angular/core';
import { IonNav } from '@ionic/angular/standalone';
import { TablesOverviewComponent } from './tables-overview';

@Component({
  selector: 'app-storage-startscreen',
  imports: [IonNav],
  templateUrl: 'storage-startscreen.html',
  standalone: true,
})
export class StorageStartscreenComponent {
  component = TablesOverviewComponent;
}
