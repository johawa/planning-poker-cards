import { Routes } from '@angular/router';
import { TabsComponent } from './components/app-tabs/tabs';

export const routes: Routes = [
  {
    path: 'main',
    component: TabsComponent,
    children: [
      {
        path: 'scan',
        loadComponent: () =>
          import('./pages/select/startscreen').then((m) => m.StartScreenComponent),
      },
      {
        path: 'storage',
        loadComponent: () =>
          import('./pages/storage/storage-startscreen').then((m) => m.StorageStartscreenComponent),
      },

      {
        path: '',
        redirectTo: '/main/scan',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: '/main/scan',
    pathMatch: 'full',
  },
];
