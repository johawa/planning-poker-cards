import { Component } from '@angular/core';
import { IonIcon, IonTabBar, IonTabButton, IonTabs } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { folderOutline, scanOutline } from 'ionicons/icons';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.html',
  styleUrls: ['tabs.css'],
  imports: [IonIcon, IonTabBar, IonTabButton, IonTabs],
})
export class TabsComponent {
  constructor() {
    addIcons({ folderOutline, scanOutline });
  }
}
