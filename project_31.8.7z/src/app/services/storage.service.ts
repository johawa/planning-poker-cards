import { inject, Injectable } from '@angular/core';
import { NgxIndexedDBService } from 'ngx-indexed-db';
import { Observable } from 'rxjs';
import { SelectService } from './select.service';
import { mockData } from './mockdata';

export interface PickingRecord {
  id?: number;
  pickerId: number;
  amount: number;
  sessionId: string;
}

@Injectable({ providedIn: 'root' })
export class StorageService {
  private storeName = 'pickings';
  #dbService = inject(NgxIndexedDBService);

  constructor() {}

  /** Save a record */
  save(record: PickingRecord) {
    console.log('save', record, this.storeName);
    this.#dbService.add(this.storeName, record).subscribe((key) => {
      console.log('key: ', key);
    });
  }

  mockDB() {
    console.log('bulkAddMock', mockData);
    this.#dbService.bulkAdd(this.storeName, mockData).subscribe((key) => {
      console.log('key: ', key);
    });
  }

  /** Get all pickings */
  getAll(): Observable<PickingRecord[]> {
    return new Observable((subscriber) => {
      this.#dbService.getAll(this.storeName).subscribe({
        next: (records) => subscriber.next(records as PickingRecord[]),
        error: (err) => subscriber.error(err),
        complete: () => subscriber.complete(),
      });
    });
  }

  /** Get all pickings for a session */
  getAllForSession(sessionId: string): Observable<PickingRecord[]> {
    return new Observable((subscriber) => {
      this.#dbService.getAll(this.storeName).subscribe({
        next: (records) => {
          const typedRecords = records as PickingRecord[];
          subscriber.next(typedRecords.filter((r) => r.sessionId === sessionId));
        },
        error: (err) => subscriber.error(err),
        complete: () => subscriber.complete(),
      });
    });
  }

  /** Delete a record by ID */
  delete(id: number): Observable<void> {
    return new Observable((subscriber) => {
      this.#dbService.delete(this.storeName, id).subscribe({
        next: () => {
          subscriber.next();
          subscriber.complete();
        },
        error: (err) => subscriber.error(err),
      });
    });
  }

  /** Delete all records for a session */
  deleteAllForSession(sessionId: string): Observable<void> {
    return new Observable((subscriber) => {
      this.getAllForSession(sessionId).subscribe({
        next: (records) => {
          const deletions = records.map((r) => this.#dbService.delete(this.storeName, r.id!));
          Promise.all(deletions.map((d) => d.toPromise()))
            .then(() => {
              subscriber.next();
              subscriber.complete();
            })
            .catch((err) => subscriber.error(err));
        },
        error: (err) => subscriber.error(err),
      });
    });
  }
}
