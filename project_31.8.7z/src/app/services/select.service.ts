import { Injectable, signal } from '@angular/core';
import { StorageService } from './storage.service';

export type BerryType = 'strawberries' | 'raspberries' | 'blueberries';

export interface SelectedOptions {
  type: BerryType | '';
  defaultWeight: number | null;
  session: string;
}

function getCurrentTime() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0'); // ensures 2 digits
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

function generateSessionName(state: SelectedOptions) {
  return `${getCurrentTime()}-${state.type}-${state.defaultWeight}`;
}

@Injectable({ providedIn: 'root' })
export class SelectService {
  constructor(private storage: StorageService) {}

  selection = signal<SelectedOptions>({
    type: '',
    defaultWeight: null,
    session: '',
  });

  updateType(selectedType: BerryType): void {
    this.selection.update((s) => ({ ...s, type: selectedType }));
  }

  updateWeight(selectedWeight: number): void {
    this.selection.update((s) => ({ ...s, defaultWeight: selectedWeight }));
  }

  startSession() {
    const newSession = generateSessionName(this.selection());
    this.selection.update((s) => ({ ...s, session: newSession }));
  }

  getSessionID(): string {
    return this.selection().session;
  }

  getState(): SelectedOptions {
    return this.selection();
  }
}
