import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-KRPMOSGQ.js";
import "./chunk-QEE7QVES.js";
import "./chunk-2H3NLAAY.js";
import "./chunk-PAXKX5KU.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
