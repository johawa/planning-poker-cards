import {
  addIcons,
  setAssetPath
} from "./chunk-ZGASCDQN.js";
import "./chunk-PAXKX5KU.js";
export {
  addIcons,
  setAssetPath
};
