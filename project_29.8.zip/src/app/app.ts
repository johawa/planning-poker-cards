import { Component, signal } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';

@Component({
  selector: 'app-root',
  templateUrl: 'app.html',
  styleUrls: ['app.css'],
  imports: [
    // TestComponent,
    // StartScreenComponent,

    IonApp,
    IonRouterOutlet,
  ],
})
export class AppComponent {
  selectionDone = signal(false);
  constructor() {}

  handleSelectionFinished() {
    console.log('handleSelection Done');
    this.selectionDone.set(true);
  }
}
