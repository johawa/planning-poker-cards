import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class NfcService {
  async scanNfc(onRead: (text: string) => void) {
    if ('NDEFReader' in window) {
      try {
        const ndef = new (window as any).NDEFReader();
        await ndef.scan();
        ndef.onreading = (event: any) => {
          const message = event.message.records[0];
          const textDecoder = new TextDecoder();
          const text = textDecoder.decode(message.data);
          onRead(text);
        };
        console.log('NFC scan started');
      } catch (error) {
        console.error('NFC scan failed', error);
      }
    } else {
      console.warn('Web NFC not supported on this device/browser');
    }
  }
}
