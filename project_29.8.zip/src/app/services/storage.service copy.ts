// import { Injectable } from '@angular/core';
// import { openDB, IDBPDatabase } from 'idb';
// import { BehaviorSubject, from, Observable } from 'rxjs';

// export interface PickingRecord {
//   id?: number; // autoIncrement primary key
//   sessionId: string; // e.g., 'picking-25.7'
//   pickerId: number;
//   amount: number;
// }

// @Injectable({ providedIn: 'root' })
// export class StorageService {
//   private dbName = 'picker-db';
//   private db!: IDBPDatabase<any>;
//   private sessions$ = new BehaviorSubject<string[]>([]);
//   private records$ = new BehaviorSubject<PickingRecord[]>([]);

//   constructor() {}

//   /** Open or create the database with a single object store */
//   private async openDb(): Promise<IDBPDatabase<any>> {
//     if (!this.db) {
//       this.db = await openDB(this.dbName, 1, {
//         upgrade(db) {
//           if (!db.objectStoreNames.contains('pickings')) {
//             db.createObjectStore('pickings', { keyPath: 'id', autoIncrement: true });
//           }
//         },
//       });
//     }
//     return this.db;
//   }

//   /** Save a picking record */
//   async save(sessionId: string, pickerId: number, amount: number) {
//     const db = await this.openDb();
//     const tx = db.transaction('pickings', 'readwrite');
//     const store = tx.objectStore('pickings');
//     await store.add({ sessionId, pickerId, amount });
//     await tx.done;
//     this.refreshSessions();
//   }

//   /** Get all records for a session */
//   async getAllForSession(sessionId: string): Promise<PickingRecord[]> {
//     const db = await this.openDb();
//     const all = await db.getAll('pickings');
//     return all.filter((r) => r.sessionId === sessionId);
//   }

//   /** Get all records for a picker in a session */
//   async getAllForPicker(sessionId: string, pickerId: number): Promise<PickingRecord[]> {
//     const sessionRecords = await this.getAllForSession(sessionId);
//     return sessionRecords.filter((r) => r.pickerId === pickerId);
//   }

//   /** Sum amounts for a picker in a session */
//   async sumAmount(sessionId: string, pickerId: number): Promise<number> {
//     const pickerRecords = await this.getAllForPicker(sessionId, pickerId);
//     return pickerRecords.reduce((sum, r) => sum + r.amount, 0);
//   }

//   /** Delete a record by id */
//   async delete(id: number) {
//     const db = await this.openDb();
//     const tx = db.transaction('pickings', 'readwrite');
//     const store = tx.objectStore('pickings');
//     await store.delete(id);
//     await tx.done;
//     this.refreshSessions();
//   }

//   /** Delete all records for a picker in a session */
//   async deleteAllForPicker(sessionId: string, pickerId: number) {
//     const pickerRecords = await this.getAllForPicker(sessionId, pickerId);
//     for (const record of pickerRecords) {
//       await this.delete(record.id!);
//     }
//   }

//   private async refreshSessions() {
//     const db = await this.openDb();
//     const all = await db?.getAll('pickings');
//     console.log('all', all);
//     if (!all) {
//       return;
//     }
//     const sessionIds = Array.from(new Set(all.map((r) => r.sessionId)));
//     this.sessions$.next(sessionIds);
//   }

//   async reload() {
//     await this.refreshSessions();
//   }

//   getRecordsForSession(sessionId: string): Observable<PickingRecord[]> {
//     return new Observable((subscriber) => {
//       const sub = this.records$.subscribe((records) => {
//         const filtered = records.filter((r) => r.sessionId === sessionId);
//         subscriber.next(filtered);
//       });
//       return () => sub.unsubscribe();
//     });
//   }

//   /** Get all sessions (unique sessionIds) as Observable */
//   getAllSessions(): Observable<string[]> {
//     return this.sessions$.asObservable();
//   }
//   /** Get all records in the database */
//   async getAll(): Promise<PickingRecord[]> {
//     const db = await this.openDb();
//     return db.getAll('pickings');
//   }
// }
