import { Component } from '@angular/core';
import { StorageService } from '../../services/storage.service';
import { NfcService } from '../../services/nfc-reader.service';
import { saveToFile } from '../../helpers/helpers';
import { IonItem, IonLabel, IonInput, IonButton, IonText } from '@ionic/angular/standalone';
import { FormsModule } from '@angular/forms';
import { SelectedOptions, SelectService } from '../../services/select.service';
import { Observable, timer, expand, map } from 'rxjs';

function getRandomDelay(): number {
  return Math.floor(Math.random() * (5000 - 1500 + 1)) + 1500; // 1500 to 5000 ms
}

function getRandomNumber(): number {
  return Math.floor(Math.random() * 10) + 1; // 1 to 10
}

const randomObservable = new Observable<number>((observer) => {
  const initialDelay = getRandomDelay();

  timer(initialDelay).subscribe(() => {
    observer.next(getRandomNumber());
  });
}).pipe(expand(() => timer(getRandomDelay()).pipe(map(() => getRandomNumber()))));

@Component({
  selector: 'app-scan',
  standalone: true,
  imports: [IonItem, IonLabel, IonInput, IonButton, FormsModule, IonText],
  templateUrl: 'scan.html',
  styleUrls: ['./scan.css'],
})
export class ScanComponent {
  userInput = '';
  state!: SelectedOptions;

  private audio = new Audio('assets/sound.wav');

  constructor(
    private storageService: StorageService,
    private nfc: NfcService,
    private selectService: SelectService
  ) {
    this.state = this.selectService.getState();

    randomObservable.subscribe((value) => {
      console.log('Random Value:', value, this.audio);
      this.audio.currentTime = 0;
      this.audio.play().catch((err) => console.error('Audio playback failed:', err));
    });
  }

  async scanNfc() {
    await this.nfc.scanNfc(async (text: string) => {
      window.prompt('NFC tag:', text);
      // await this.storage.saveInput('lastNfc', text);
    });
  }

  saveInput() {
    const sessionId = this.selectService.getSessionID();
    const pickerId = 11; // will come from nfc chip;
    const amount = 3;
    const update = {
      pickerId,
      amount,
      sessionId,
    };

    // this.storageService.save(update);
    this.storageService.mockDB();
    this.userInput = '';
  }
}
