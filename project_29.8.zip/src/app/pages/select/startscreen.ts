import { Component } from '@angular/core';
import { IonNav } from '@ionic/angular/standalone';
import { StepOneComponent } from './step-one.component';

@Component({
  selector: 'app-startscreen',
  imports: [IonNav],
  templateUrl: 'startscreen.html',
  standalone: true,
})
export class StartScreenComponent {
  component = StepOneComponent;
}
