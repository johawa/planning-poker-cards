import { Component } from '@angular/core';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonTitle,
  IonToolbar,
  NavParams,
} from '@ionic/angular/standalone';
import { StorageService, PickingRecord } from '../../services/storage.service';
import { map, Observable, tap } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { saveToFile } from '../../helpers/helpers';
import { addIcons } from 'ionicons';
import { download, downloadOutline } from 'ionicons/icons';

type PickerData = {
  pickerId: number;
  amount: number;
  sessionId: string;
};

type GroupedResult = {
  pickerId: number | 'total';
  totalAmount: number;
  allData: PickerData[];
};

function groupByPickerId(data: PickerData[]): GroupedResult[] {
  const grouped = data.reduce((acc, entry) => {
    const { pickerId, amount } = entry;
    if (!acc[pickerId]) {
      acc[pickerId] = { pickerId, totalAmount: 0, allData: [] };
    }
    acc[pickerId].totalAmount += amount;
    acc[pickerId].allData.push(entry);
    return acc;
  }, {} as Record<number, GroupedResult>);

  const resultArray = Object.values(grouped);

  const totalAll = resultArray.reduce((sum, r) => sum + r.totalAmount, 0);
  resultArray.unshift({
    pickerId: 'total',
    totalAmount: totalAll,
    allData: data,
  });

  return resultArray;
}

@Component({
  selector: 'app-table',
  imports: [
    IonHeader,
    IonTitle,
    IonToolbar,
    IonBackButton,
    IonButtons,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    AsyncPipe,
    IonIcon,
    IonFab,
    IonFabButton,
  ],
  templateUrl: 'table.html',
  standalone: true,
})
export class TableComponent {
  tableData$!: Observable<any[]>;
  sessionId = '';

  constructor(private navParams: NavParams, private storageService: StorageService) {
    addIcons({ downloadOutline });
    const sessionId = this.navParams.get('sessionId');
    if (sessionId) {
      this.tableData$ = this.storageService.getAllForSession(sessionId).pipe(
        tap((data) => console.log('transformedData', groupByPickerId(data))),
        map((data) => groupByPickerId(data))
      );
    }
  }

  export() {
    this.sessionId = this.navParams.get('sessionId');
    this.storageService.getAllForSession(this.sessionId).subscribe((data) => {
      let allData = '';
      for (const key of data) {
        allData += `${key.pickerId}: ${key.amount}\n`;
      }
      console.log('data', data);
      saveToFile(allData, this.sessionId);
    });
  }
}
